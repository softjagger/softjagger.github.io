Sligoil is a trademark of Ariel Martín Pérez and Godolphin Games (2022).
