PicNic is a trademark of Marielle Nils.
