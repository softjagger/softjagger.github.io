FONTLOG for Mourier
-------------------

This file provides detailed information on the Mourier font software.
This information should be distributed along with the Demo fonts
and any derivative works.


Basic Font Information
--------------------------

Mourier by Eric Mourier.
Contributed by Sebastien Hayez, Alexander Kondratenko and Ariel Martín Perez.


Information for Contributors
------------------------------

Mourier is released under the OFL 1.1 - http://scripts.sil.org/OFL

For information on what you're allowed to change or modify, consult the
OFL-1.1.txt and OFL-FAQ.txt files. The OFL-FAQ also gives a very general
rationale and various recommendations regarding why you would want to
contribute to the project or make your own version of the font.

See the project website for the current trunk and the various branches:

http://velvetyne.fr/fonts/mourier


ChangeLog
----------

When you make modifications, be sure to add a description of your changes,
following the format of the other entries, to the start of this section.

2020 (Alexander Kondratenko and Ariel Martín Perez) - V 2.0
Cyrillic capitals extension (Alexander Kondratenko)
Latin lowercase & diacritics, Cyrillic lowercase, more symbols, new alternates (Ariel Martín Perez)

2011 (Sébastien Hayez) - V 1.0
- Publication on the Velvetyne Type Foundry (www.velvetyne.fr)

2002 (Sébastien Hayez)
- Revival

1971 (Éric Mourier)
- Original design

Acknowledgements
-------------------------

When you make modifications, be sure to add your name (N), email (E),
web-address (W) and description (D). This list is sorted by last name in
alphabetical order.

N: Ariel Martín Pérez
E: contact@arielgraphisme.com
W: http://arielgraphisme.com
D: Latin lowercase & diacritics, Cyrillic lowercase, more symbols, new alternates

N: Alex Ash (Alexander Kondratenko)
E: 
W: https://www.artstation.com/alexkond
D: Cyrillic capitals extension

N: Sébastien Hayez
E: hayezsebastien@hotmail.com
W: http://sebastienhayez.fr
D: Revival

N: Eric Mourier
E: ?
W: ?
D: Original design
